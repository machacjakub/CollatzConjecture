import React, { useState } from 'react';
import React from 'react';

function Header() {
  return (
    <div className="header">
      <b>Collatz conjecture</b>
    </div>
  );
}

export default Header;
